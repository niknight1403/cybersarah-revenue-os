# Deep Void — Design-System Integration

## Was das ist

Eine eigenständige CSS-/Komponenten-Schicht, die sich über dein bestehendes
Dashboard legt — **kein Rewrite** jeder einzelnen Seite nötig. Du integrierst
es schrittweise, Seite für Seite, in deinem eigenen Tempo.

## Schritt 1 — Einbinden (einmalig, 2 Minuten)

In `artifacts/dashboard/src/main.tsx`, ganz oben:
```ts
import "./styles/void-theme.css";
```

## Schritt 2 — Demo ansehen

Route in `App.tsx` ergänzen:
```tsx
import DesignDemo from "@/pages/design-demo";
// ...
<Route path="/design-demo" component={DesignDemo} />
```

Dann `pnpm build`, Server neu starten, und `https://cybersarah-ki.de/design-demo`
aufrufen — zeigt alle Bausteine auf einen Blick: atmende Agenten-Punkte,
Glass-Blob-Karten, Gold-Umsatzwerte, fließende Datenstrom-Ränder.

## Schritt 3 — Schrittweise auf bestehende Seiten anwenden

**Einfachster Einstieg — nur den Hintergrund wechseln:**
In `layout.tsx`, das äußerste Wrapper-Div bekommt `className="void-canvas"`
zusätzlich zu was schon da ist. Das allein ändert schon Hintergrund + Textfarbe
im ganzen Dashboard.

**Karten ersetzen, Seite für Seite:**
```tsx
// Vorher:
import { Card, CardContent } from "@/components/ui/card";
<Card><CardContent>...</CardContent></Card>

// Nachher:
import { GlassBlobCard } from "@/components/ui/glass-card";
<GlassBlobCard>...</GlassBlobCard>
```

**Agenten-Status anzeigen** (z.B. im HARA- oder Master-Agent-Dashboard):
```tsx
import { AgentOrb } from "@/components/ui/agent-orb";

<AgentOrb status={agent.laeuft ? "beschaeftigt" : "aktiv"} label={agent.name} />
```

Den `status` direkt an echte Agent-Daten koppeln (z.B. `agent.letzterLauf`,
`agent.status === "erfolgreich"` → `"erfolg"`) — das ist der "State-Driven UI"-
Teil aus deinem Briefing: die Animation spiegelt echten Systemzustand, nicht
nur Deko.

## Was NICHT enthalten ist (bewusst, wegen Aufwand/Risiko)

- **Kein WebGL/Canvas-Renderer.** Das Briefing erwähnt das als Option für die
  fließenden Hintergrund-Gradienten — hier stattdessen mit performantem CSS
  gelöst (radial-gradient, Blur, CSS-Animationen). Läuft auf jedem Gerät ohne
  Shader-Kompilierung, GPU-Treiber-Abhängigkeit oder zusätzliche Bundle-Größe.
  Falls du später einen echten Partikel-Canvas-Hintergrund willst (aufwendiger,
  aber beeindruckender), ist das ein eigener, größerer Folge-Sprint.
- **Nicht jede der ~20 Dashboard-Seiten ist umgestellt.** Das wäre ein sehr
  großer Eingriff auf einmal — stattdessen hast du hier das komplette
  Baukasten-System, das du Seite für Seite anwenden kannst, ohne Risiko den
  ganzen Dashboard-Build auf einen Schlag kaputt zu machen.

## Farbwerte zur Referenz

| Verwendung | Von | Nach |
|---|---|---|
| Hintergrund | `#050814` (Deep Void) | — |
| Agenten-Aktivität | `#00F2FE` | `#4FACFE` |
| Umsatz/Erfolg | `#F6D365` | `#FDA085` |
| Text primär | `#F2F4FA` | — |
| Text gedämpft | `#8890B5` | — |
